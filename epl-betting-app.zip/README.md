# epl-betting-app
Project assignment for SoftUni's React Fundamentals course
